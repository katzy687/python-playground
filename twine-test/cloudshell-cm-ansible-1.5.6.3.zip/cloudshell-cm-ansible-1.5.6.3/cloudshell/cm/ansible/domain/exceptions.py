class AnsibleException(Exception):
    pass


class CancellationException(Exception):
    pass