from cloudshell.workflow.orchestration.sandbox import Sandbox

sandbox = Sandbox()

sandbox.execute_save()